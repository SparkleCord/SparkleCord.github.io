// Global variables
function rand(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min);
}
let profile = JSON.parse(localStorage.getItem("profile")) || {};
profile.username ||= `sparklecord_user_${rand(1, 99999)}`;
profile.name ||= "SparkleCord User";
profile.avatar ||= `./assets/avatars/${rand(1, 10)}.png`;
profile.status ||= "Online";
let messageGroups = [];
let lastMessageTimestamp = null;
let currentMessageGroup = null;
let history = [""];
let historyIndex = 0;
let lastMessage = null;
let lastMessageAuthor = null;
let lastMessageAvatar = null;
let sendButton = null;
// Strings
const $ = (id) => document.getElementById(id);
const defaultEmojiDesc = "A default emoji. You can use this emoji everywhere on SparkleCord.";
const LOADING_TIME = rand(3000, 6500); // Milliseconds
const arrowLeftHook = "←", arrowUpHook = "↑", arrowRightHook = "→", arrowDownHook = "↓";
const versionCode = "1.0.0";
const versionName = "public_beta";
const versionType = "Client";
const versionHtml = `SparkleCord ${versionType} Version ${versionCode} <br>(${versionName})`;
const rootPath = (() => {
    const path = window.location.href;
    if (window.location.protocol === 'file:') { return path.substring(0, path.lastIndexOf('/') + 1); }
    return window.location.origin + window.location.pathname.substring(0, window.location.pathname.lastIndexOf('/') + 1);
})();
console.log('SparkleCord is currently running on', rootPath)
const LOADING_LINES = [
    /* All lines were written by doctoon unless stated otherwise */
    // SparkleCord OLD lines
    { text: "Self-Love has never been easier!", weight: 1 },
    { text: "You can customize your profile!", weight: 1 },
    { text: "SparkleCord keeps you connected.... with yourself...", weight: 1 },
    { text: "Enjoy chatting with ~~friends~~ yourself!", weight: 1 },
    // Modified Discord lines
    // if u want the original lines, check out https://gist.github.com/fourjr/f94fc112cef6da07fc274216d5755420
    { text: "SparkleCord was almost called SparkAccord when I was looking for better names. Not too proud of that one.", weight: 1 },
    { text: 'There are a bunch of hidden "Easter Eggs" in the app that happen when you click certain things...', weight: 1 },
    { text: "SparkleCord started off as just a silly project that barely looked or acted like Discord.", weight: 1 },
    { text: "SparkleCord's official birthday is February 29th, 2024.", weight: 1 },
    // Keybinds
    { text: "[[SHIFT]] + [[ENTER]] to make a new line without sending your message.", weight: 1 },
    { text: `You can press [[${arrowUpHook}]] to quickly edit your most recent message.`, weight: 1 },
    // Tips
    { text: `You can change your role color at ${rootPath}css/base/variables.css`, weight: 1 },
    { text: "You can drag and drop files onto SparkleCord to upload them.", weight: 1 },
    { text: "\\Do **this** for bold, *this* for italic, and the rest? idk i'll get them later.\\", weight: 1 },
    { text: "Customize SparkleCord's appearance in the user settings menu.", weight: 1 },
    { text: "You can right click a message to Edit, [Delete]{var(--status-danger)}, And more!", weight: 1 },
    // Custom SparkleCord lines
    { text: "There was an error loading SparkleCord, have a 🗣🔥 instead :D", weight: 1 },
    { text: "Loading the loading line, Please wait... ↻", weight: 1 },
    { text: "Messages aren't stored anywhere!", weight: 1 },
    { text: "hello bob...", weight: 1 },
    { text: "99% of people are chronically on Discord. Be happy you're the 1% using SparkleCord.", weight: 1, author: "gdtapioka" },
    { text: "too lazy to add a loading screen message, check back later.", weight: 1, author: "gdtapioka" },
    { text: "doctoon was here", weight: 1 },
    { text: "Big Berry saved our logo from being just a white sparkle emoji.", weight: 1 },
    { text: "SparkleCord was created on a Thursday at 11:43:41 PM GMT+2.", weight: 1 },
    { text: "I'm NEVER adding official light mode support, sorry bub.", weight: 1 },
    { text: "SparkleCord will always be a web-based app.", weight: 1 },
    // Time-specific lines
    { text: "I used SparkleCord at 3 AM (Gone Wrong) (Police Called) 😱😱😱", condition: () => getUTCDate().getHours() === 3, weight: 10 },
    // Holiday-specific lines
    { text: "Merry Halloween! I hope you got your easter eggs... wait... did I say that right?", holiday: "HALLOWEEN", weight: 3 },
    { text: "All I want for christmas... is meeeeeeee.....", holiday: "CHRISTMAS", weight: 3 },
     // Condition-specific lines
    { text: "SparkleCord: Best experienced under the moonlight. 🌙", condition: () => { let h = getUTCDate().getHours(); return h >= 20 || h < 6; }, weight: 10 },
    { text: localStorage.getItem("custom-loading-line") || "", condition: () => JSON.parse(localStorage.getItem("custom-line-enabled") || "false"), weight: 10000 },
    { text: "You're not supposed to see this. 👀", condition: () => JSON.parse(localStorage.getItem("secret-setting") || "false"), weight: 10 },
    { text: `Welcome back, ${JSON.parse(localStorage.getItem("profile") || "{}").name || "User"}!`, condition: () => true, weight: 1 },
    { text: `Loading... Status: ${JSON.parse(localStorage.getItem("profile") || "{}").status || "Online"}`, condition: () => true, weight: 1 }
];
const getUTCDate = (dateString = null) => {
    if (dateString) return new Date(dateString);
    return new Date();
    //return new Date('2025-10-31 03:00:00');
};
const isHoliday = (date) => {
    const month = date.getUTCMonth();
    const day = date.getUTCDate();
    const holidays = {
        BIRTHDAY_DISCORD: { month: 5, start: 13, end: 20 }, // May 13th
        BIRTHDAY: { month: 2, start: 29, end: 30 }, // February 29th - February 30th
        HALLOWEEN: { month: 10, start: 1, end: 31 }, // October 1 - October 31st
        CHRISTMAS: { month: 12, start: 1, end: 31 }, // December 1 - December 31st
    };
    for (const [name, period] of Object.entries(holidays)) { if (month === (period.month - 1) && day >= period.start && day <= period.end) { return name; } }
    return null;
};
const getSpinnerPath = (holiday) => {
    const spinners = {
        BIRTHDAY_DISCORD: './assets/loading/Discord.gif',
        BIRTHDAY: './assets/loading/Birthday.gif',
        HALLOWEEN: './assets/loading/Halloween.gif',
        CHRISTMAS: './assets/loading/Christmas.gif',
        DEFAULT: './assets/loading/Default.gif'
    };
    return spinners[holiday] || spinners.DEFAULT;
};
const updateSpinner = () => {
    const spinner = document.getElementById('spinner');
    const currentHoliday = isHoliday(getUTCDate());
    spinner.src = getSpinnerPath(currentHoliday);
};
function showLoadingScreen(loadingTime) {
    function getRandomLine() {
        const currentDate = getUTCDate();
        const currentHoliday = isHoliday(currentDate);
        const validLines = LOADING_LINES.filter(line => {
            if (line.holiday && line.holiday !== currentHoliday) return false;
            if (line.condition && !line.condition()) return false;
            return true;
        });
        const totalWeight = validLines.reduce((sum, line) => sum + (line.weight || 1), 0);
        let random = Math.random() * totalWeight;
        for (const line of validLines) { random -= (line.weight || 1); if (random <= 0) return line.text; }
        return validLines[0].text;
    }
    function showLoadingLine() {
        const lineElement = document.getElementById('loading-line');
        const didYouKnow = document.getElementById('loading-text');
        didYouKnow.innerHTML = 'Did You Know';
        const randomLine = getRandomLine();
        // const randomLine = LOADING_LINES[0];
        lineElement.innerHTML = parseMarkdown(randomLine);
        const spinner = document.getElementById('spinner');
        const currentHoliday = isHoliday(getUTCDate());
        if (currentHoliday) {
            const holidaySpinner = getSpinnerPath(currentHoliday);
            if (spinner.src !== holidaySpinner) { spinner.src = holidaySpinner; }
        }
    }
    function hideLoadingScreen() {
        const loadingScreen = document.getElementById('loading-screen');
        loadingScreen.classList.add('hide');
        loadingScreen.addEventListener('animationend', () => {
            loadingScreen.remove();
        });
    }
    showLoadingLine();
    setTimeout(hideLoadingScreen, loadingTime);
}
// Functoins
function initConsoleMessages() {
    console.log("%cHold Up!", 
        "color: #5865f2; -webkit-text-stroke: 2px black; font-size: 85px; font-weight: bold; font-family: 'Consolas';");
    console.log("%cThere is no hidden developer or online mode, the only developer options are there for testing and debugging and are already available.", 
        "color: oklab(0.89908 -0.00192907 -0.0048306); font-size: 22px; font-family: 'Consolas';");
    console.log("%cThere is no light mode either!! if someone tries to trick you into pasting a script that \"enables light mode early\", it's 101% a scam.",
        "color: #f23f43; font-size: 22px; font-family: 'Consolas'; font-weight: bold;");
    console.log("%cMake sure to never run scripts from untrusted sources! If where you got the script looks sketchy, don't run it.", 
        "color: oklab(0.89908 -0.00192907 -0.0048306); font-size: 22px; font-family: 'Consolas';");
    console.log("%cIf you have any internal questions about SparkleCord, just DM me on Discord (doctoon).", 
        "color: oklab(0.89908 -0.00192907 -0.0048306); font-size: 22px; font-family: 'Consolas';");
}
// amazing function i love
function updateSendButtonColor() {
    if (sendButton) {
        const messageInput = $("input-box"); sendButton.setAttribute('fill', messageInput?.value.trim() ? 'var(--send-enabled)' : 'var(--send-disabled)');
    }
}