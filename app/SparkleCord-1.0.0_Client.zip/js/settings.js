function openSettingsPanel() {
    document.getElementById("settings-panel").style.display = "flex";
    document.getElementById("global-name-input").value = profile.name;
    document.getElementById("status-input").value = profile.status;
    document.getElementById("username-input").value = profile.username;
}
function closeSettingsPanel() { document.getElementById("settings-panel").style.display = "none"; }
function applySettings() {
    const sendBtnToggle = JSON.parse(localStorage.getItem("send-btn-toggle"));
    if (sendBtnToggle !== null) toggleSendButton(sendBtnToggle);
}
const settingsData = {
    "User Settings": {
        profile: { 
            name: "Profile", 
            options: [
                { label: "Global Name", type: "text", id: "global-name-input" },
                { label: "Username", type: "text", id: "username-input" },
                { label: "Status Text", type: "text", id: "status-input" },
                { label: "Avatar", type: "file", id: "avatar-input", accept: "image/*" }
            ], 
            button: { text: "Save Profile", id: "save-profile-btn", onClick: saveProfile }
        },
    },
    "App Settings": {
        appearance: { 
            name: "Appearance", 
            options: [
                { label: "Show Send Message Button", type: "toggle", id: "send-btn-toggle", onToggle: toggleSendButton, default: "on", description: "Self explanatory." }
            ]
        },
        utility: {
            name: "Utility",
            options: [
                {
                    label: "Automatically convert emoticons in your messages to emoji", 
                    type: "toggle", 
                    id: "auto-convert-emoticons", 
                    onToggle: toggleEmoticonConversion, 
                    default: "off",
                    description: "For example, when you type :) SparkleCord will convert it to :slight_smile:",
                }
            ]
        },
        loading: {
            name: "Loading",
            options: [
                { label: "Loading Line", type: "text", id: "line-input" },
                { label: "Use Custom Loading Line", type: "toggle", id: "custom-line", onToggle: toggleLoadingLine, default: "off", description: `Uses the custom loading line you set above instead of SparkleCord default, for Example: "The app is loading :o". `, }
            ],
            button: { text: "Save Settings", id: "save-loading-settings", onClick: saveLoadingSettings }
        }
    },
    "Developer Settings": {
        experiments: { 
            name: "Experiments", 
            options: [
                { 
                    label: "Experimental Option", 
                    type: "toggle", 
                    id: "experimental-option", 
                    onToggle: toggleSecretSetting, 
                    default: "off",
                    description: "Keep in mind this is **__experimental__**, Things may break."
                },
            ]
        },
        examples: { 
            name: "Examples", 
            options: [
                { 
                    label: "Enable/Disable Nothing", 
                    type: "toggle", 
                    id: "secret-mode-toggle", 
                    onToggle: toggleSecretSetting, 
                    default: "off",
                    description: "This option is simply used to _**test**_ things... :scream:"
                },
                {
                    label: "Disabled (Wihthout Depends)", 
                    type: "toggle", 
                    id: "disabled-option", 
                    onToggle: toggleEmoticonConversion, 
                    default: "off",
                    description: "Yes...",
                    disabled: true
                },
                {
                    type: "custom", 
                    id: "custom-option", 
                    html: `<code>hello everyone this is your daily dose of geometry dash</code>`
                },
                { 
                    label: "Depends (PARENT)", 
                    type: "toggle", 
                    id: "example-depends-parent", 
                    onToggle: toggleSecretSetting, 
                    default: "off",
                    description: "Keep in mind this is **__experimental__**, Things may break."
                },
                { 
                    label: "Depends (CHILD)", 
                    type: "toggle", 
                    id: "example-depends-child", 
                    onToggle: toggleSecretSetting, 
                    default: "off",
                    description: "Keep in mind this is **__experimental__**, Things may break.",
                    dependsOn: "example-depends-parent"
                }
            ]
        }
    }
};
function createSettingsPanel() {
    const settingsPanel = document.createElement("div"); settingsPanel.id = "settings-panel"; settingsPanel.className = "hidden"; settingsPanel.style.display = "flex";
    settingsPanel.innerHTML = `
        <div id="settings-container">
            <div class="close-container">
                <div id="close-settings-btn" aria-label="Close" role="button">
                    <svg aria-hidden="true" role="img" xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" viewBox="0 0 24 24"><path fill="var(--icon)" d="M17.3 18.7a1 1 0 0 0 1.4-1.4L13.42 12l5.3-5.3a1 1 0 0 0-1.42-1.4L12 10.58l-5.3-5.3a1 1 0 0 0-1.4 1.42L10.58 12l-5.3 5.3a1 1 0 1 0 1.42 1.4L12 13.42l5.3 5.3Z" class=""></path></svg>
                </div>
            </div>
            <div id="settings-sidebar"></div>
            <div id="settings-content"></div>
        </div>
    `;
    document.getElementById("settings-panel-container").appendChild(settingsPanel);
    document.getElementById("close-settings-btn").addEventListener("click", closeSettingsPanel);
    let sidebarHTML = "", contentHTML = "";
    Object.entries(settingsData).forEach(([category, sections]) => {
        sidebarHTML += `<div class="eyebrow">${category}</div>`;
        Object.entries(sections).forEach(([key, section], index) => {
            sidebarHTML += `<button class="settings-tab" data-tab="${key}-settings">${section.name}</button>`;
            let optionsHTML = `<h2>${section.name}</h2>`;
            section.options.forEach(opt => {
                if (opt.type === "info") {optionsHTML += `<p>${opt.label}</p>`;
                } else if (opt.type === "toggle") {
                    let isChecked = JSON.parse(localStorage.getItem(opt.id)) ?? (opt.default === "on");
                    let isDisabled = (opt.dependsOn && !(JSON.parse(localStorage.getItem(opt.dependsOn)) ?? false)) || opt.disabled === true;
                    optionsHTML += `
                        <div class="toggle-container${isDisabled ? ' disabled' : ''}">
                            <span class="label-text">${parseMarkdown(opt.label)}</span>
                            <label class="switch">
                                <input type="checkbox" id="${opt.id}"
                                    ${isChecked ? "checked" : ""} ${isDisabled ? "disabled" : ""} ${opt.dependsOn ? `data-depends-on="${opt.dependsOn}"` : ""}
                                    ${opt.disabled ? "data-force-disabled" : ""} >
                                <span class="slider"></span>
                            </label>
                            ${opt.description ? `<p class="small-normal" style="margin-top: -10px;"> ${parseMarkdown(opt.description)}</p>` : ''}
                        </div>`;
                } else if (opt.type === "custom") {optionsHTML += `${opt.html}`;
                } else { optionsHTML += `<label for="${opt.id}">${opt.label}</label> <input type="${opt.type}" id="${opt.id}" ${opt.accept ? `accept="${opt.accept}"`:""}>`; }
            });
            if (section.button) optionsHTML += `<button id="${key}-button">${section.button.text}</button>`;
            contentHTML += `<div id="${key}-settings" class="settings-section hidden">${optionsHTML}</div>`;
        });
    });
    function updateDependentToggleState(toggle, parentEnabled) {
        const container = toggle.closest('.toggle-container');
        if (toggle.hasAttribute('data-force-disabled')) { return; }
        toggle.disabled = !parentEnabled;
        container.classList.toggle('disabled', !parentEnabled);
        if (!parentEnabled && toggle.checked) {
            toggle.checked = false;
            localStorage.setItem(toggle.id, false);
            Object.values(settingsData)
                .flatMap(cat => Object.values(cat))
                .forEach(section => { const option = section.options.find(opt => opt.id === toggle.id); option?.onToggle?.(false); });
        }
    }
    document.getElementById("settings-sidebar").innerHTML = sidebarHTML; 
    document.getElementById("settings-content").innerHTML = contentHTML;

    const versionElement = document.createElement("p");
    versionElement.id = "version-info";
    versionElement.innerHTML = versionHtml;
    versionElement.style.cssText = `
        cursor: pointer; user-select: none; color: oklab(0.686636 -0.00407365 -0.0149199); font: 12px normal 400;
        line-height: 16px; padding: 5px; position: absolute; bottom: 5px; left: 1.5%; text-align: center;
    `; 
    document.getElementById("settings-sidebar").appendChild(versionElement);
    versionElement.addEventListener("click", () => {
        navigator.clipboard.writeText(versionElement.textContent.trim());
        versionElement.style.color = "var(--status-positive)";
        setTimeout(() => {
            versionElement.style.color = "oklab(0.686636 -0.00407365 -0.0149199)";
        }, 200);        
    });    

    const tabs = document.querySelectorAll(".settings-tab"), sections = document.querySelectorAll(".settings-section");
    tabs[0].classList.add("active");
    sections[0].classList.remove("hidden");
    tabs.forEach(tab => tab.addEventListener("click", () => {
        tabs.forEach(t => t.classList.remove("active"));
        sections.forEach(s => s.classList.add("hidden"));
        tab.classList.add("active");
        document.getElementById(tab.dataset.tab).classList.remove("hidden");
    }));
    document.querySelectorAll(".settings-section button").forEach(button => {
        let key = button.id.replace("-button", "");
        Object.entries(settingsData).forEach(([_, sections]) => {
            if (sections[key]?.button?.onClick) { button.addEventListener("click", sections[key].button.onClick); }
        });
    });
    document.querySelectorAll(".switch input").forEach(toggle => {
        if (toggle.hasAttribute('data-force-disabled')) { return; }
        if (toggle.hasAttribute('data-depends-on')) {
            const parentId = toggle.getAttribute('data-depends-on');
            const parent = document.getElementById(parentId);
            updateDependentToggleState(toggle, parent.checked);
            parent.addEventListener('change', (e) => { updateDependentToggleState(toggle, e.target.checked); });
        }
        toggle.addEventListener("change", (e) => {
            localStorage.setItem(e.target.id, e.target.checked);
            Object.values(settingsData)
                .flatMap(cat => Object.values(cat))
                .forEach(section => { const option = section.options.find(opt => opt.id === e.target.id); option?.onToggle?.(e.target.checked); });
        });
    });
    document.addEventListener("keydown", (e) => { if (e.key === KEYBIND_CLOSE_SETTINGS) { e.preventDefault(); closeSettingsPanel(); }});
}
// Settings > Profile
function loadProfile() {
    document.getElementById("profile-picture").src = profile.avatar;
    document.getElementById("global-name").textContent = profile.name;
    document.getElementById("username").textContent = profile.status;
}
function saveProfile() {
    const name = document.getElementById("global-name-input").value;
    const username = document.getElementById("username-input").value;
    const status = document.getElementById("status-input").value || "Online";
    const avatarInput = document.getElementById("avatar-input");
    let avatar = profile.avatar;
    if (avatarInput.files.length > 0) {
        const reader = new FileReader();
        reader.onloadend = () => { 
            profile = { username, name, status, avatar: reader.result }; 
            localStorage.setItem("profile", JSON.stringify(profile)); 
            loadProfile(); 
        };
        reader.readAsDataURL(avatarInput.files[0]);
    } else { 
        profile = { username, name, status, avatar }; 
        localStorage.setItem("profile", JSON.stringify(profile)); 
        loadProfile(); 
    }
    closeSettingsPanel();
}
// Settings > Appearance
function toggleSendButton(isChecked) { document.getElementById("send-btn").classList.toggle("hidden", !isChecked); }
// Srttings > Utility
function toggleEmoticonConversion(isChecked) {
    localStorage.setItem('auto-convert-emoticons', isChecked);
}
function convertEmoticons(text) {
    if (!JSON.parse(localStorage.getItem('auto-convert-emoticons'))) { return text; }
    const sortedEmoticons = Object.keys(emoticonJson).sort((a, b) => b.length - a.length);
    const pattern = new RegExp(sortedEmoticons.map(e =>  e.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|'), 'g');
    return text.replace(pattern, match => `:${emoticonJson[match]}:`);
}
// Settings > Loading
function toggleLoadingLine(isChecked) {
    localStorage.setItem("custom-line-enabled", isChecked);
}
function saveLoadingSettings() {
    const line = document.getElementById("line-input").value;
    localStorage.setItem("custom-loading-line", line);
}
// Settings > Developer
function toggleSecretSetting(isChecked) { 
    console.log(`Wait... YOU CLICKED THE SECRET SETTING?!?!?! IT\'S NOW ${isChecked.toString().toUpperCase()}`);
    localStorage.setItem("secret-setting", isChecked);
}