async function sendMessage() {
    const messageInput = document.getElementById("input-box"), content = messageInput.value.trim(), hasAttachments = currentAttachments.length > 0;
    if (!content && !hasAttachments) return;
    const sanitizedContent = sanitizeInput(content);
    const convertedContent = convertEmoticons(sanitizedContent);    
    const timestamp = new Date().toISOString(), data = { author: profile.name, content: convertedContent, timestamp, avatar: profile.avatar, attachments: [] };
    if (hasAttachments) {
        for (const attachment of currentAttachments) {
            const fileContent = await processFileForMessage(attachment);
            data.attachments.push({ id: attachment.id, name: attachment.name, type: attachment.type, size: formatFileSize(attachment.size), content: fileContent });
        }
    }
    let formattedContent = '';
    let hasMentions = false;
    if (content) {
        const mentionNames = ["everyone", "here", "you", "me", "someone", profile.username, profile.name];
        const mentionPattern = new RegExp(`@(${mentionNames.join("|")})\\b`, "gi");
        hasMentions = mentionPattern.test(content);
        mentionPattern.lastIndex = 0;
        formattedContent = convertedContent
            .replace(mentionPattern,(_,mention)=>`<span class="ping">@${mention.toLowerCase()===profile.name.toLowerCase()?profile.name:mention.toLowerCase()}</span>`);
        formattedContent = parseMarkdown(formattedContent);
    }
    let messageHTML = '';
    if (formattedContent) {messageHTML += `<div class="content">${formattedContent}</div>`;}
    if (hasAttachments) {
        messageHTML += `<div class="attachments">`;
        for (const attachment of data.attachments) {
            if (attachment.type.startsWith('image/')) {
                messageHTML += `
                    <div class="attachment media">
                        <img src="${attachment.content}" alt="${attachment.name}">
                    </div>`;
            } else if (attachment.type.startsWith('video/')) {
                messageHTML += `
                    <div class="attachment media-video">
                        <video controls src="${attachment.content}"></video>
                    </div>`;
            } else if (attachment.type.startsWith('audio/')) {
                messageHTML += `
                    <div class="attachment media-audio">
                    <img class="file-icon" src="${getFileIcon(attachment.type)}">
                        <audio controls src="${attachment.content}"></audio>
                        <a href="${attachment.content}" class="link" target="_blank">${attachment.name}</a>
                        <span class="file-size">${attachment.size}</span>
                    </div>`;
            } else {
                messageHTML += `
                    <div class="attachment file-other">
                        <img class="file-icon" src="${getFileIcon(attachment.type)}">
                        <a href="${attachment.content}" class="link" target="_blank">${attachment.name}</a>
                        <span class="file-size">${attachment.size}</span>
                    </div>`;
            }
        }
        messageHTML += `</div>`;
    }
    let groupMessage = null, isGrouped = false;
    if (lastMessageTimestamp && lastMessageAuthor === data.author && lastMessageAvatar === data.avatar) {
        const timeDiff = (new Date(timestamp) - new Date(lastMessageTimestamp)) / (1000 * 60); if (timeDiff < 10) { groupMessage = currentMessageGroup; isGrouped = true; }
    }
    if (!groupMessage || document.getElementById("messages").children.length === 0) {
        groupMessage = document.createElement("div"); groupMessage.classList.add("message-group"); document.getElementById("messages").appendChild(groupMessage);
        isGrouped = false;
    }
    const messageElement = document.createElement("div"); messageElement.classList.add("message");
    if (isGrouped) messageElement.classList.add("grouped");
    if (hasMentions) messageElement.classList.add("mention");
    messageElement.setAttribute("data-timestamp", timestamp); messageElement.setAttribute("data-content", content); messageElement.setAttribute("data-author", data.author);
    messageElement.innerHTML = isGrouped ?
        `<div class="message-background"><div class="message-content">${messageHTML}</div></div>` :
        `<img class="profile-pic" src="${data.avatar}"><div class="message-background"><div class="message-content"><div class="author">${data.author} <span class="timestamp">${formatTimestamp(timestamp)}</span></div>${messageHTML}</div></div>`;
    groupMessage.appendChild(messageElement);
    applyHighlighting(messageElement);
    lastMessageTimestamp = timestamp; lastMessageAuthor = data.author; lastMessageAvatar = data.avatar;
    currentMessageGroup = groupMessage; lastMessage = messageElement; messageInput.value = ''; history.push(""); historyIndex = history.length - 1;
    currentAttachments = []; const attachmentWrappers = document.querySelectorAll('.attachment-wrapper'); attachmentWrappers.forEach(wrapper => wrapper.remove());
    scrollToBottom();
    updateSendButtonColor();
}
// Helper function to process file for message
async function processFileForMessage(attachment) {
    return new Promise((resolve) => { const reader = new FileReader(); reader.onload = (e) => { resolve(e.target.result); }; reader.readAsDataURL(attachment.file); });
}
// Scroll to Bottom
function scrollToBottom() { const messagesContainer = document.getElementById("messages"); messagesContainer.scrollTop = messagesContainer.scrollHeight; }
// highlight syntax
function applyHighlighting(messageElement) {
    const codeBlocks = messageElement.querySelectorAll('pre code');
    codeBlocks.forEach(codeBlock => {
        const langClass = codeBlock.className.replace('hljs', '').replace('language-', '').trim();
        loadHighlight(langClass).then(() => {
            const code = codeBlock.textContent;
            try {
                const highlighted = hljs.highlight(code, { language: HLJS_ALIASES[langClass] || langClass || 'plaintext', ignoreIllegals: true }).value;
                codeBlock.innerHTML = highlighted;
                addCopyButton(codeBlock.parentElement);
            } catch (err) {
                console.warn('Highlighting failed, falling back to plaintext:', err);
                codeBlock.innerHTML = hljs.highlight(code, { language: 'plaintext', ignoreIllegals: true }).value;
                addCopyButton(codeBlock.parentElement);
            }
        }).catch(err => { console.error('Highlight error:', err); codeBlock.textContent = codeBlock.textContent; });
    });
}
// prevent people from trying to run code using html so people don't try hacking and shit
function sanitizeInput(input) {
    return input.replace(/(```[\s\S]*?```|`[^`\n]*`)|([<>&"'`])/g, (match, codeBlock, char) => 
        codeBlock ? match : (char === '>' && match === char) ? '>' : {'<': '&lt;', '&': '&amp;', '"': '&quot;', "'": '&#39;', '`': '&#96;'}[char]
    );       
}