// Timestamps
function formatTimestamp(timestamp) { return `Today at ${new Date(timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`; }
if (!window._spoilerHandlerAdded) {
    document.addEventListener('click', (e) => { if (e.target.classList.contains('spoiler')) { e.target.classList.toggle('revealed'); } });
    window._spoilerHandlerAdded = true;
}
// trap the tab key
function setupFocusTrap(container) {
    const focusableSelectors = 'a[href], button:not([disabled]), textarea:not([disabled]), input:not([disabled]), select:not([disabled])';
    const firstDummy = document.createElement('div');
    firstDummy.tabIndex = 0;
    firstDummy.className = 'focus-trap-dummy';
    const lastDummy = document.createElement('div');
    lastDummy.tabIndex = 0;
    lastDummy.className = 'focus-trap-dummy';
    container.insertBefore(firstDummy, container.firstChild);
    container.appendChild(lastDummy);
    firstDummy.addEventListener('focus', () => {
        const focusableElements = container.querySelectorAll(focusableSelectors);
        if (focusableElements.length) { focusableElements[focusableElements.length - 1].focus(); }
    });
    lastDummy.addEventListener('focus', () => {
        const focusableElements = container.querySelectorAll(focusableSelectors);
        if (focusableElements.length) {focusableElements[0].focus(); }
    });
}