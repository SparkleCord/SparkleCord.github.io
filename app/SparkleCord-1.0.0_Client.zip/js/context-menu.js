// Context menu Builder
class MessageActivities {
    constructor() {
        this.lastMessage = null;
        this.contextMenuItems = [
           // { id: "react-msg", label: "Add Reaction", action: (msg) => this.reactTo(msg, reaction), icon: `./assets/svg/ctx/React.svg` },
            { id: "edit-msg", label: "Edit Message", action: (msg) => this.editMessage(msg), icon: `./assets/svg/ctx/Edit.svg` },
           // { id: "reply-msg", label: "Reply", action: (msg) => this.replyTo(msg), icon: `./assets/svg/ctx/Reply.svg` },
            { id: "copy-msg", label: "Copy Text", action: (msg) => this.copyMessage(msg), icon: `./assets/svg/ctx/Copy.svg` },
            { id: "copy-inner-html", label: "Copy HTML", action: (msg) => this.copyHTML(msg), icon: `./assets/svg/ctx/Copy.svg` },
            { id: "delete-msg", label: "Delete Message", action: (msg) => this.deleteMessage(msg), destructive: true, icon: `./assets/svg/ctx/Delete.svg` },
        ];
        this.init();
    }
    init() {
        this.contextMenu = document.createElement("div");
        this.contextMenu.id = "context-menu";
        this.contextMenuItems.forEach(({ id, label, action, destructive, icon }) => {
            const menuItem = document.createElement("div"); menuItem.className = `menu-item${destructive ? " delete" : ""}`; menuItem.id = id;
            const wrapper = document.createElement("div"); wrapper.className = "menu-item-content";
            const labelSpan = document.createElement("span"); labelSpan.textContent = label; wrapper.appendChild(labelSpan);
            if (icon) {
                const iconSpan = document.createElement("span"); iconSpan.className = "menu-item-icon";
                if (icon.startsWith('<svg')){iconSpan.innerHTML = icon;}else if (icon.match(/\.(svg)$/i)) {iconSpan.innerHTML=`<img src="${icon}" alt="">`;}
                wrapper.appendChild(iconSpan);
            }
            menuItem.appendChild(wrapper);
            menuItem.addEventListener("click", () => action(this.lastMessage));
            this.contextMenu.appendChild(menuItem);
        });
        document.body.appendChild(this.contextMenu);
        const messagesContainer = document.getElementById("messages");
        messagesContainer.addEventListener("click", (e) => {
            if (e.target.classList.contains("message-content")) this.lastMessage = e.target.closest(".message");
        });
        messagesContainer.addEventListener("contextmenu", (e) => {
            e.preventDefault();
            const message = e.target.closest(".message");
            if (!message) return;
            this.lastMessage = message;
            const menu = this.contextMenu, menuRect = menu.getBoundingClientRect();
            let x = e.clientX, y = e.clientY;
            if (x + menuRect.width > window.innerWidth) { x = window.innerWidth - menuRect.width; }
            if (y + menuRect.height > window.innerHeight) { y = window.innerHeight - menuRect.height; }
            x = Math.max(0, x); y = Math.max(0, y);
            menu.style.left = `${x}px`; menu.style.top = `${y}px`; menu.classList.add("show");
        });
        document.addEventListener("click", () => this.contextMenu.classList.remove("show"));
        document.addEventListener("keydown", (e) => {
            const inputBox = document.querySelector("#input-box");
            const editBoxActive = document.querySelector(".edit-box");
            if (e.key === KEYBIND_EDIT && !editBoxActive) {
                if (!inputBox.value) { e.preventDefault(); if (this.lastMessage) this.editMessage(this.lastMessage); }
            }
        });        
    }
    addContextMenuItem(id, label, action, destructive = false, icon = null) {
        const menuItem = document.createElement("div"); menuItem.className = `menu-item${destructive ? " delete" : ""}`; menuItem.id = id;
        const wrapper = document.createElement("div"); wrapper.className = "menu-item-content";
        const labelSpan = document.createElement("span"); labelSpan.textContent = label; wrapper.appendChild(labelSpan);
        if (icon) {
            const iconSpan = document.createElement("span"); iconSpan.className = "menu-item-icon";
            if (icon.startsWith('<svg')){iconSpan.innerHTML = icon;}else if (icon.match(/\.(svg|png|jpg|jpeg|gif)$/i)) {iconSpan.innerHTML=`<img src="${icon}" alt="">`;}
            wrapper.appendChild(iconSpan);
        }
        menuItem.appendChild(wrapper);
        menuItem.addEventListener("click", () => action(this.lastMessage));
        this.contextMenu.appendChild(menuItem);
        this.contextMenuItems.push({ id, label, action, destructive, icon });
    }
    // Operation Functions
    deleteMessage(msg) {
        const messageGroup = msg.closest(".message-group");
        if (!messageGroup) return;
        const isFirst = msg === messageGroup.firstElementChild;
        msg.remove();
        if (messageGroup.children.length === 0) return messageGroup.remove();
        if (isFirst) {
            const newFirst = messageGroup.firstElementChild;
            newFirst.classList.remove("grouped");
            const avatar = profile.avatar;
            const author = profile.name;
            const timestamp = newFirst.getAttribute("data-timestamp");
            const content = newFirst.querySelector(".content").innerHTML;
            newFirst.innerHTML = `
                <img class="profile-pic" src="${avatar}">
                <div class="message-background">
                    <div class="message-content">
                        <div class="author">${author} <span class="timestamp">${formatTimestamp(timestamp)}</span></div>
                        <div class="content">${content}</div>
                    </div>
                </div>
            `;
            this.lastMessageTimestamp = timestamp;
            this.lastMessageAuthor = author;
            this.lastMessageAvatar = avatar;
        }
    }
    editMessage(msg) {
        const contentElement = msg.querySelector(".content");
        const content = msg.getAttribute("data-content");
        if (!content) return;
        const container = document.createElement("div"); container.className = "edit-container";
        const input = document.createElement("textarea"); input.className = "edit-box"; input.value = content;
        const editOps = document.createElement("div"); editOps.className = "editOperations";
        const cancelButton = document.createElement("a"); cancelButton.className = "link"; cancelButton.role = "button"; cancelButton.textContent = "cancel";
            cancelButton.style.cursor = "pointer";
        const saveButton = document.createElement("a"); saveButton.className = "link"; saveButton.role = "button"; saveButton.textContent = "save";
            saveButton.style.cursor = "pointer";
        editOps.appendChild(document.createTextNode("escape to ")); editOps.appendChild(cancelButton);
        editOps.appendChild(document.createTextNode(" • enter to ")); editOps.appendChild(saveButton);
        container.appendChild(input); container.appendChild(editOps);
        const parent = contentElement.parentNode;
        parent.replaceChild(container, contentElement);
        input.focus();
        const saveEdit = () => {
            input.removeEventListener("blur", cancelEdit);
            const newTextTemp = input.value.trim();
            const newText = sanitizeInput(newTextTemp)
            if (!newText) { msg.remove(); return; }
            const wasEdited = contentElement.querySelector(".edited-tag");
            parent.replaceChild(contentElement, container);
            contentElement.innerHTML = parseMarkdown(newText);
            msg.setAttribute("data-content", newTextTemp);
            applyHighlighting(msg);
            if (wasEdited || (newTextTemp !== content && !contentElement.innerHTML.includes(" (edited)"))) {
                const tag = document.createElement("span");
                tag.className = "edited-tag";
                tag.textContent = " (edited)";
                contentElement.appendChild(tag);
            }
        };
        const cancelEdit = () => { if (container.parentNode === parent) { parent.replaceChild(contentElement, container); } };
        cancelButton.addEventListener("click", (e) => { e.preventDefault(); cancelEdit(); });
        saveButton.addEventListener("click", (e) => { e.preventDefault(); saveEdit(); });
        input.addEventListener("keydown", (e) => {
            if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); saveEdit(); }
            if (e.key === "Escape") { e.preventDefault(); cancelEdit(); }
        });
    }
    replyTo(msg) {
        // Add potential variables like 'isReplyMention', 'toWho' and 'replyContent0'
        console.log(`@${profile.name}: \'${msg.getAttribute("data-content")}\,`)
        console.log(`${msg.getAttribute("data-content")}`)
    }
    reactTo(msg) {
        // Add an emoji variable which includes a unicode emoji in 16x15 size [it converts it to an svg similar to emoji handling.]
        console.log(`@${profile.name}: \'${msg.getAttribute("data-content")}\,`)
        console.log(`${msg.getAttribute("data-content")}`)
    }
    copyMessage(msg) {
        const messageContent = msg.getAttribute("data-content");
        navigator.clipboard.writeText(messageContent);
        console.log(`Copied successfully! (Today at ${new Date(new Date().toISOString()).toLocaleTimeString([])})`);
    }
    copyHTML(msg) {
        let messageContent = msg.classList.contains('grouped') ?  msg.innerHTML : msg.querySelector('.message-content').innerHTML;
        messageContent = messageContent.replace(/data:([^;]+);base64,([^"'\s>]+)/g, (match, mimeType, base64) => `data:${mimeType};base64,${base64.substring(0, 20)}...` );
        navigator.clipboard.writeText(messageContent);
        console.log(`Copied successfully! (Today at ${new Date(new Date().toISOString()).toLocaleTimeString([])})`);
    }
}
document.addEventListener("DOMContentLoaded", () => {
    // Example Option
   // messageActivities.addContextMenuItem("report-msg", "Report Message", (msg) => {
       // console.log("bro really tried reporting", `@${msg.getAttribute("data-author")}`, "'s message 💀😭🙏");
   // }, false, `./assets/svg/ctx/Report.svg`);
});