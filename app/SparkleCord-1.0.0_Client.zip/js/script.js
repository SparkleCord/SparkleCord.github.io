document.addEventListener("DOMContentLoaded", () => {
    const $ = (id) => document.getElementById(id);
    initConsoleMessages();
    $("send-btn").addEventListener("click", sendMessage);
    $("message-input").addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } });
    $("settings-btn").addEventListener("click", openSettingsPanel);
    document.addEventListener("keydown", (e) => {
        if (e.ctrlKey && e.key === KEYBIND_OPEN_SETTINGS) { openSettingsPanel(); e.preventDefault(); }
    });
    $('attach-btn').addEventListener('click', handleFileAttachment);
    const dropOverlay = document.createElement("div"); dropOverlay.className = "drop-overlay"; dropOverlay.innerHTML = `
        <div class="drop-content">
            <img src="./assets/svg/file/Upload a File.svg">
            <span>Drag files here to upload them into SparkleCord</span>
        </div>
    `;
    $('app').appendChild(dropOverlay);
    $('app').addEventListener("dragenter", (e) => {if (e.dataTransfer.types.includes('Files')) {dropOverlay.classList.add("active");}});
    $('app').addEventListener("dragleave", (e) => { if (e.relatedTarget === null || !$('app').contains(e.relatedTarget)) { dropOverlay.classList.remove("active"); } });
    $('app').addEventListener("dragover", (e) => { e.preventDefault(); e.stopPropagation(); });
    $('app').addEventListener("drop", (e) => { e.preventDefault(); e.stopPropagation(); dropOverlay.classList.remove("active");
        const files = Array.from(e.dataTransfer.files); if (!files.length) return; files.forEach(file => createAttachmentPreview(file));
    });
    $('app').addEventListener("paste", (e) => {
        const files = Array.from(e.clipboardData.files); if (!files.length) return; files.forEach(file => createAttachmentPreview(file));
    });
    loadProfile();
    setupFocusTrap($("app"));
    sendButton = $("send-btn").querySelector("path");
    const messageInput = $("input-box");
    messageInput.addEventListener("input", () => {
         if (messageInput.value !== history[historyIndex]) { history = history.slice(0, historyIndex + 1); history.push(messageInput.value); historyIndex++; } 
         updateSendButtonColor();
    });
    messageInput.addEventListener("keydown", (e) => {
        if (e.ctrlKey && e.key === "z") { if (historyIndex > 0) { historyIndex--; messageInput.value = history[historyIndex]; } e.preventDefault(); }
        if ((e.ctrlKey && e.key === "y") || (e.ctrlKey && e.shiftKey && e.key === "z")) { if (historyIndex < history.length - 1) { historyIndex++; messageInput.value = history[historyIndex]; } e.preventDefault(); }
        updateSendButtonColor();
    });
    messageInput.addEventListener("keydown", async (e) => {
        if (e.ctrlKey && e.key === 'c') { if (messageInput.selectionStart === messageInput.selectionEnd) { 
                e.preventDefault(); try { await navigator.clipboard.writeText(''); } catch (err) { console.error(err) }
            }
        }
    });
    updateSendButtonColor();
    createSettingsPanel();
    closeSettingsPanel();
    applySettings();
    const messageActivities = new MessageActivities();
    showLoadingScreen(LOADING_TIME);
});