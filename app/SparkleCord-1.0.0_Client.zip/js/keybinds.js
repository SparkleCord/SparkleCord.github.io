const KEYBIND_EDIT = "ArrowUp";
const KEYBIND_CLOSE_SETTINGS = "Escape";
const KEYBIND_OPEN_SETTINGS = "k"