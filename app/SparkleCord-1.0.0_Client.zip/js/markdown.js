function parseMarkdown(text) {
    // escape blocks but like in a cooler way or smth
    const codeBlocks = []; 
    text = text.replace(/```(\w*)\n([\s\S]+?)\n```/g, (match, lang, code) => {
        codeBlocks.push({ lang: lang.toLowerCase() || 'plaintext', code: code.trim() });
        return `\u0000\u0001C${codeBlocks.length - 1}\u0001\u0000`;
    });
    const iC=[];text=text.replace(/`([^`]+)`/g,(match,code)=>{iC.push(code);return`\u0000\u0001I${iC.length-1}\u0001\u0000`;});
    const eB=[];text=text.replace(/\\(.*?)\\/g,(match,content)=>{eB.push(content);return`\u0000\u0001E${eB.length-1}\u0001\u0000`;});
    // emoji replacement
    text = replaceEmojiNames(text, false);
    text = replaceEmojis(text, false);
    // normal markdown
    text = text.replace(/\[([^\]]+)\]\(([^)]+)\)/g,(_,t,u)=>{u=u.replace(/<[^>]*>/g,'');return`<a href="${u}"class="link"target="_blank"title="${t+'\n\n'}(${u})">${t}</a>`;})// Masked links
    .replace(/\b((https?|ftp|file):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/gi, 
        '<a href="$1" class="link" target="_blank" title="$1/">$1/</a>') // Normal links
        // CUSTOM MARKDOWN THAT WASN'T IN DISCORD OR SMTH
        .replace(/\[\[(.*?)\]\]/g, '<span class="keybind">$1</span>') // Like those keys from discord's settings lmao
        .replace(/{{(.*?)}}/g, '<span class="badge">$1</span>') // NEW
        .replace(/\[([^\]]+)\]{([^}]+)}/g, '<span style="color: $2">$1</span>') // Colored text [text]{color}
        .replace(/{!#([^*]+)}/g, '<span style="font-family: var(--font-headline);">$1</span>') // Headline
        // discord markdown
        .replace(/^-# (.*$)/gm, '<span class="small-normal">$1</span>') // Subtext
        .replace(/^-# > (.*$)/gm, '<span class="small-normal"><blockquote>$1</blockquote></span>') // Blockquotes (Subtext)
        .replace(/\|\|([^|]+)\|\|/g, '<span class="spoiler">$1</span>') // Spoiler
        .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>') // Bold
        .replace(/__(.*?)__/g, '<u>$1</u>') // Underline
        .replace(/\*([^*]+)\*/g, '<em>$1</em>') // Italic (*italic*)
        .replace(/(?<!\\)_((?:[^_]|\\_)+?)(?<!\\)_/g, '<em>$1</em>') // Italic (_italic_)
        .replace(/~~(.*?)~~/g, '<s>$1</s>') // Strikethrough
        .replace(/^### (.*$)/gm, '<h3>$1</h3>\u0000\u0003') // Heading 3
        .replace(/^## (.*$)/gm, '<h2>$1</h2>\u0000\u0003') // Heading 2
        .replace(/^# (.*$)/gm, '<h1>$1</h1>\u0000\u0003') // Heading 1
         // ordered or unorderd lists
        .replace(/^> (.*$)/gm, '<blockquote>$1</blockquote>\u0000\u0003') // Blockquotes
    text = text.replace(/\n/g, "<br>").replace(/\u0000\u0003<br>/g, ''); // break of the line variant
    // ```code```
    text = text.replace(/\u0000\u0001C(\d+)\u0001\u0000/g, (match, index) => {
        const block = codeBlocks[parseInt(index)], lang = block.lang, escapedCode = escapeHtml(block.code);
        return '<div class="code-wrapper"><pre><code class="hljs language-' + lang + '">' + escapedCode + '</code></pre></div>';
    });
    text = text.replace(/\u0000\u0001I(\d+)\u0001\u0000/g, (match, index) => `<code>${iC[parseInt(index)]}</code>`); // inline `code`
    text = text.replace(/\u0000\u0001E(\d+)\u0001\u0000/g, (match, index) => eB[parseInt(index)] ); // block restoration
    text = text.replace(/\\_\\_/g, '_'); // for fixing emojis
    text = text.replace(/\u0000\u0003/g, ''); // line break remove markers
    return text;
}
function escapeHtml(text) {
    return text.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;");
}